/**
 * Background script for Group Order Splitter
 * Handles storage, communication between popup and content script
 */

// Import security manager with error handling
let securityManager;
try {
  importScripts('security.js');
} catch (error) {
  console.error('Security manager failed to load:', error);
  // Create fallback security manager
  securityManager = {
    validateExtensionContext: () => {},
    checkRateLimit: () => true,
    encrypt: async (data) => data,
    decrypt: async (data) => data,
    logSecurityEvent: () => {}
  };
}

// Default settings
const DEFAULT_SETTINGS = {
  dailyBudget: 14,
  currency: 'EUR',
  tikkieLink: '' // Will be stored encrypted
};

/**
 * Extract Tikkie URL from text that may contain additional content
 * Supports both direct URLs and full message text
 */
function extractTikkieUrl(text) {
  if (!text || typeof text !== 'string') {
    return null;
  }

  // Tikkie URL pattern - matches https://tikkie.me/pay/... URLs
  const tikkieUrlPattern = /https:\/\/tikkie\.me\/pay\/[a-zA-Z0-9]+/g;

  // First, try to match the exact pattern
  const matches = text.match(tikkieUrlPattern);

  if (matches && matches.length > 0) {
    // Return the first valid Tikkie URL found
    return matches[0];
  }

  // If no pattern match, check if the entire text is a direct Tikkie URL
  try {
    const url = new URL(text.trim());
    if (url.hostname === 'tikkie.me' && url.pathname.startsWith('/pay/')) {
      return text.trim();
    }
  } catch (e) {
    // Not a valid URL, continue with other checks
  }

  // Check for common variations (www.tikkie.me, app.tikkie.me)
  const extendedPattern = /https:\/\/(www\.|app\.)?tikkie\.me\/pay\/[a-zA-Z0-9]+/g;
  const extendedMatches = text.match(extendedPattern);

  if (extendedMatches && extendedMatches.length > 0) {
    return extendedMatches[0];
  }

  return null;
}

// Initialize extension
chrome.runtime.onInstalled.addListener(async () => {
  // Set default settings if not already set
  const settings = await chrome.storage.sync.get(DEFAULT_SETTINGS);
  await chrome.storage.sync.set(settings);
});

// Handle messages from content script and popup
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  switch (message.type) {
    case 'GET_SETTINGS':
      handleGetSettings(sendResponse);
      return true; // Keep message channel open for async response
      
    case 'UPDATE_SETTINGS':
      handleUpdateSettings(message.settings, sendResponse);
      return true;
      
    case 'CALCULATE_ORDER':
      handleCalculateOrder(message.data, sendResponse);
      return true;
      
    case 'LOG_ERROR':
      console.error('Content script error:', message.error);
      break;
      
    default:
      console.warn('Unknown message type:', message.type);
  }
});

// Get current settings with secure Tikkie link handling
async function handleGetSettings(sendResponse) {
  try {
    // Validate extension context for security
    securityManager.validateExtensionContext();

    const result = await chrome.storage.sync.get(DEFAULT_SETTINGS);
    // Properly merge settings, ensuring zero values are preserved
    const settings = { ...DEFAULT_SETTINGS };

    // Only use defaults for undefined/null values, not for 0 or false
    Object.keys(result).forEach(key => {
      if (result[key] !== undefined && result[key] !== null) {
        settings[key] = result[key];
      }
    });



    // Decrypt Tikkie link if present and encrypted
    if (settings.tikkieLink && settings.tikkieLink.startsWith('encrypted:')) {
      try {
        const encryptedData = settings.tikkieLink.substring(10); // Remove 'encrypted:' prefix
        const decryptedLink = await securityManager.decrypt(encryptedData);

        // Validate decrypted URL
        const validation = securityManager.validateTikkieUrl(decryptedLink);
        if (validation.valid) {
          settings.tikkieLink = validation.url;
        } else {
          console.warn('Invalid Tikkie URL detected, clearing:', validation.error);
          settings.tikkieLink = '';
          securityManager.logSecurityEvent('invalid_tikkie_url_retrieved', {
            error: validation.error
          });
        }
      } catch (error) {
        console.error('Failed to decrypt Tikkie link:', error);
        settings.tikkieLink = '';
        securityManager.logSecurityEvent('tikkie_decryption_failed', {
          error: error.message
        });
      }
    }

    sendResponse({ success: true, settings });
  } catch (error) {
    console.error('Error getting settings:', error);
    securityManager.logSecurityEvent('settings_retrieval_failed', {
      error: error.message
    });
    sendResponse({ success: false, error: error.message });
  }
}

// Update settings with secure Tikkie link handling
async function handleUpdateSettings(newSettings, sendResponse) {
  try {
    // Validate extension context for security
    try {
      securityManager.validateExtensionContext();
    } catch (secError) {
      console.warn('Security validation failed, continuing anyway:', secError);
    }

    // Rate limiting for settings updates
    try {
      securityManager.checkRateLimit('settings_update', 10, 60000);
    } catch (rateError) {
      console.warn('Rate limiting failed, continuing anyway:', rateError);
    }

    // Create a copy of settings for processing
    const settingsToStore = { ...newSettings };

    // Validate and process Tikkie link if present
    if (settingsToStore.tikkieLink !== undefined) {
      try {
        const rawInput = settingsToStore.tikkieLink.trim();

        if (rawInput === '') {
          // Empty link is valid
          settingsToStore.tikkieLink = '';
        } else {
          // Extract Tikkie URL from text (supports both direct URLs and message text)
          const extractedUrl = extractTikkieUrl(rawInput);

          if (extractedUrl) {
            // Validate the extracted URL
            try {
              new URL(extractedUrl); // This will throw if invalid URL
              settingsToStore.tikkieLink = extractedUrl;
            } catch (urlError) {
              console.warn('Extracted URL is invalid:', urlError.message);
              settingsToStore.tikkieLink = '';
            }
          } else {
            // No valid Tikkie URL found in the input
            console.warn('No valid Tikkie URL found in input text');
            settingsToStore.tikkieLink = '';
          }
        }

        securityManager.logSecurityEvent('tikkie_url_processed', {
          hasLink: settingsToStore.tikkieLink.length > 0,
          linkLength: settingsToStore.tikkieLink.length,
          wasExtracted: rawInput !== settingsToStore.tikkieLink
        });

      } catch (validationError) {
        console.error('Tikkie processing failed:', validationError);
        // If all validation fails, store empty string to prevent blocking other settings
        settingsToStore.tikkieLink = '';
      }
    }

    // Store settings
    try {
      await chrome.storage.sync.set(settingsToStore);
      sendResponse({ success: true });
    } catch (storageError) {
      console.error('Storage operation failed:', storageError);
      sendResponse({
        success: false,
        error: `Storage failed: ${storageError.message}`
      });
      return;
    }

    // Prepare settings for notification (with decrypted Tikkie link)
    const notificationSettings = { ...settingsToStore };
    if (notificationSettings.tikkieLink && notificationSettings.tikkieLink.startsWith('encrypted:')) {
      notificationSettings.tikkieLink = newSettings.tikkieLink; // Use original unencrypted value
    }

    // Notify all content scripts about settings change
    const tabs = await chrome.tabs.query({ url: 'https://www.thuisbezorgd.nl/*' });
    tabs.forEach(tab => {
      chrome.tabs.sendMessage(tab.id, {
        type: 'SETTINGS_UPDATED',
        settings: notificationSettings
      }).catch(() => {
        // Ignore errors for tabs without content script
      });
    });

    securityManager.logSecurityEvent('settings_updated', {
      hasEncryptedTikkie: settingsToStore.tikkieLink.startsWith('encrypted:')
    });

  } catch (error) {
    console.error('Error updating settings:', error);
    securityManager.logSecurityEvent('settings_update_failed', {
      error: error.message
    });
    sendResponse({ success: false, error: error.message });
  }
}

// Handle calculation request
async function handleCalculateOrder(orderData, sendResponse) {
  try {
    const settings = await chrome.storage.sync.get(DEFAULT_SETTINGS);
    const result = calculateOrderDistribution(orderData, settings);
    sendResponse({ success: true, result });
  } catch (error) {
    console.error('Error calculating order:', error);
    sendResponse({ success: false, error: error.message });
  }
}

// Calculate order distribution
function calculateOrderDistribution(orderData, settings) {
  const { people, delivery, service, discount } = orderData;
  const budget = settings.dailyBudget || DEFAULT_SETTINGS.dailyBudget;
  
  const extraFeesTotal = delivery + service;
  const participantNames = Object.keys(people);
  const extraPerPerson = participantNames.length > 0 ? extraFeesTotal / participantNames.length : 0;
  
  const results = {};
  const orderSubtotal = Object.values(people).reduce((a, b) => a + b, 0);
  
  participantNames.forEach((name) => {
    const subtotal = people[name];
    let total = subtotal + extraPerPerson;
    
    // Apply proportional discount if any exists
    if (discount !== 0 && orderSubtotal > 0) {
      const ratio = subtotal / orderSubtotal;
      total += ratio * discount;
    }
    
    const overage = Math.max(0, total - budget);
    results[name] = parseFloat(overage.toFixed(2));
  });
  
  // Calculate remaining extra for order owner
  const grandTotal = orderSubtotal + extraFeesTotal + discount;
  const totalBudget = budget * participantNames.length;
  const extraForOwner = Math.max(0, grandTotal - totalBudget);
  
  if (extraForOwner > 0) {
    results['You (Order Owner)'] = parseFloat(extraForOwner.toFixed(2));
  }
  
  return {
    results,
    breakdown: {
      orderSubtotal,
      delivery,
      service,
      discount,
      grandTotal,
      totalBudget,
      extraForOwner,
      participantCount: participantNames.length
    }
  };
}
